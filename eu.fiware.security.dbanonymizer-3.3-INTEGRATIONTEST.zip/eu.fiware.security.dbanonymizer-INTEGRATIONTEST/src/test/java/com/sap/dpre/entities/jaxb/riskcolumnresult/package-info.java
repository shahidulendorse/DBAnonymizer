/**
 * 
 */
/**
 * @author I069922
 *
 */
package com.sap.dpre.entities.jaxb.riskcolumnresult;